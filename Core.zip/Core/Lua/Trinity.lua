-- Trinity: Addon pour TESO, aide au farm, leveling, stuff meta et métiers

Trinity = {}
Trinity.name = "Trinity"
Trinity.version = "1.0"

function Trinity.OnAddOnLoaded(event, addonName)
    if addonName ~= Trinity.name then return end
    EVENT_MANAGER:UnregisterForEvent(Trinity.name, EVENT_ADD_ON_LOADED)
    -- Initialisation des modules principaux
    Trinity.resources = {}
    Trinity.farm = {}
    Trinity.leveling = {}
    Trinity.metaGear = {}
    Trinity.professionHelper = {}
    -- Affichage dynamique des ressources sur la carte (minerais, plantes, coffres)
    local RESOURCE_PIN_TYPE = "TRINITY_RESOURCE_PIN"
    local RESOURCE_PIN_LAYOUT = {
        level = 50,
        texture = "/esoui/art/icons/quest_giver.dds",
        size = 32,
    }

    Trinity.resources.data = {}
    Trinity.resources.lootTimestamps = {}

    local function OnResourceLooted(eventCode, receivedBy, itemName, quantity, soundCategory, lootType, lootedBySelf)
        if not lootedBySelf then return end
        local x, y, zone = GetMapPlayerPosition("player")
        local timestamp = GetTimeStamp()
        table.insert(Trinity.resources.data, {x = x, y = y, zone = GetCurrentMapZoneIndex(), name = itemName, time = timestamp})
        table.insert(Trinity.resources.lootTimestamps, timestamp)
        CALLBACK_MANAGER:FireCallbacks("TRINITY_RESOURCE_ADDED")
    end

    function Trinity.resources.ShowFarmStats()
        local now = GetTimeStamp()
        local count = 0
        for _, t in ipairs(Trinity.resources.lootTimestamps) do
            if now - t <= 3600 then count = count + 1 end
        end
        d("|c00FF00[Trinity]|r Ressources lootées la dernière heure : " .. count)
    end

    function Trinity.resources.ShowRespawnTimers()
        local now = GetTimeStamp()
        for _, res in ipairs(Trinity.resources.data) do
            local elapsed = now - res.time
            d(string.format("|c00FF00[Trinity]|r %s : il y a %d secondes", res.name, elapsed))
        end
    end

    local function ResourcePinCallback(pinManager)
        for _, res in ipairs(Trinity.resources.data) do
            if res.zone == GetCurrentMapZoneIndex() then
                pinManager:CreatePin(RESOURCE_PIN_TYPE, nil, res.zone, res.x, res.y)
            end
        end
    end

    local function CreateResourcePins()
        if not MAP_PIN_MANAGER then return end
        MAP_PIN_MANAGER:AddCustomPin(RESOURCE_PIN_TYPE, ResourcePinCallback, nil, RESOURCE_PIN_LAYOUT)
    end

    EVENT_MANAGER:RegisterForEvent(Trinity.name .. "_LOOT", EVENT_LOOT_RECEIVED, OnResourceLooted)
    CALLBACK_MANAGER:RegisterCallback("TRINITY_RESOURCE_ADDED", CreateResourcePins)
    CreateResourcePins()

    -- Helper métiers : routes et conseils pour chaque métier
    function Trinity.professionHelper.ShowBestRoute(profession)
        local routes = {
            ["alchimie"] = {
                {x = 0.22, y = 0.31},
                {x = 0.28, y = 0.36},
                {x = 0.35, y = 0.42},
            },
            ["forge"] = {
                {x = 0.45, y = 0.55},
                {x = 0.48, y = 0.60},
                {x = 0.52, y = 0.65},
            },
            ["couture"] = {
                {x = 0.62, y = 0.72},
                {x = 0.66, y = 0.75},
                {x = 0.70, y = 0.78},
            },
        }
        local selected = routes[profession]
        if not selected then
            d("|cFF0000[Trinity]|r Métier non supporté.")
            return
        end
        local PIN_TYPE = "TRINITY_PROF_ROUTE"
        local PIN_LAYOUT = {
            level = 70,
            texture = "/esoui/art/icons/poi/poi_crafting_complete.dds",
            size = 26,
        }
        local function ProfRoutePinCallback(pinManager)
            for i, point in ipairs(selected) do
                pinManager:CreatePin(PIN_TYPE, nil, GetCurrentMapZoneIndex(), point.x, point.y)
            end
        end
        if MAP_PIN_MANAGER then
            MAP_PIN_MANAGER:AddCustomPin(PIN_TYPE, ProfRoutePinCallback, nil, PIN_LAYOUT)
        end
        d("|c00FF00[Trinity]|r Route optimale pour " .. profession .. " affichée sur la carte.")
    end

    function Trinity.professionHelper.ShowLevelingTips(profession)
        local tips = {
            ["alchimie"] = "Ramassez toutes les plantes et faites des potions simples pour XP rapidement.",
            ["forge"] = "Démontez tout l’équipement trouvé et fabriquez des dagues pour optimiser l’XP.",
            ["couture"] = "Récupérez les matériaux sur les mobs et fabriquez des ceintures pour XP efficacement.",
        }
        d("|c00FF00[Trinity]|r Conseil métier " .. profession .. " : " .. (tips[profession] or "Astuces non disponibles."))
    end

    function Trinity.farm.ShowFarmRoutes()
        local FARM_ROUTE_PIN_TYPE = "TRINITY_FARM_ROUTE"
        local FARM_ROUTE_PIN_LAYOUT = {
            level = 60,
            texture = "/esoui/art/icons/poi/poi_waypoint_complete.dds",
            size = 28,
        }
        local route = {
            {x = 0.2, y = 0.3},
            {x = 0.4, y = 0.5},
            {x = 0.6, y = 0.7},
        }
        local function FarmRoutePinCallback(pinManager)
            for i, point in ipairs(route) do
                pinManager:CreatePin(FARM_ROUTE_PIN_TYPE, nil, GetCurrentMapZoneIndex(), point.x, point.y)
            end
        end
        if MAP_PIN_MANAGER then
            MAP_PIN_MANAGER:AddCustomPin(FARM_ROUTE_PIN_TYPE, FarmRoutePinCallback, nil, FARM_ROUTE_PIN_LAYOUT)
        end
        d("|c00FF00[Trinity]|r Route de farm affichée sur la carte.")
    end

    function Trinity.leveling.ShowLevelingTips()
        local level = GetUnitLevel("player")
        if level < 10 then
            d("|c00FF00[Trinity]|r Conseil leveling : Faites les quêtes principales pour XP rapidement.")
        elseif level < 50 then
            d("|c00FF00[Trinity]|r Conseil leveling : Faites les donjons aléatoires et les zones publiques.")
        else
            d("|c00FF00[Trinity]|r Conseil leveling : Passez en Champion Points, optimisez vos sets.")
        end
    end

    function Trinity.metaGear.ShowMetaGear()
        local _, classId = GetUnitClass("player")
        local meta = {
            [1] = {
                name = "Chevalier-Dragon",
                stats = "Magie : 32000+, Santé : 18000+, Critique : 50%, Penetration : 18000",
                meta = "Pillar of Nirn (Donjon Falkreath Hold), Kinras's Wrath (Donjon Black Drake Villa)",
                alt = "Briarheart (zone Wrothgar), Hunding's Rage (craftable)",
            },
            [2] = {
                name = "Lame Noire",
                stats = "Vigueur : 32000+, Critique : 50%, Penetration : 18000",
                meta = "Tzogvin's Warband (Frostvault), Leviathan (Crypt of Hearts I/II)",
                alt = "Spriggan's Thorns (Bangkorai), Night Mother's Gaze (craftable)",
            },
            [3] = {
                name = "Sorcier",
                stats = "Magie : 32000+, Critique : 50%, Penetration : 18000",
                meta = "Mother's Sorrow (Deshaan), Medusa (Arx Corinium)",
                alt = "Law of Julianos (craftable), Spinner's Garments (Malabal Tor)",
            },
            [4] = {
                name = "Templier",
                stats = "Magie : 32000+, Critique : 50%, Penetration : 18000",
                meta = "Burning Spellweave (City of Ash I/II), Julianos (craftable)",
                alt = "Silks of the Sun (Stonefalls), Magnus' Gift (craftable)",
            },
            [5] = {
                name = "Gardien",
                stats = "Magie : 32000+, Critique : 50%, Penetration : 18000",
                meta = "Frostbite (Blackwood), Winter's Respite (Western Skyrim)",
                alt = "Ysgramor's Birthright (Eastmarch), Julianos (craftable)",
            },
            [6] = {
                name = "Nécromancien",
                stats = "Magie : 32000+, Critique : 50%, Penetration : 18000",
                meta = "False God's Devotion (Sunspire), Mantle of Siroria (Cloudrest)",
                alt = "Mother's Sorrow (Deshaan), Julianos (craftable)",
            },
            [7] = {
                name = "Arcaniste",
                stats = "Magie : 32000+, Critique : 50%, Penetration : 18000",
                meta = "Whorl of the Depths (Graven Deep), Pillar of Nirn (Falkreath Hold)",
                alt = "Order's Wrath (High Isle), Julianos (craftable)",
            },
        }
        local info = meta[classId]
        if info then
            d("|c00FF00[Trinity]|r Classe : " .. info.name)
            d("|c00FF00[Trinity]|r Stats recommandées : " .. info.stats)
            d("|c00FF00[Trinity]|r Stuff meta : " .. info.meta)
            d("|c00FF00[Trinity]|r Stuff alternatif : " .. info.alt)
        else
            d("|cFF0000[Trinity]|r Classe non supportée.")
        end
    end

    -- UI de configuration via LibAddonMenu-2.0
    local function CreateSettingsPanel()
        if not LibAddonMenu2 then return end
        local panelData = {
            type = "panel",
            name = "Trinity",
            displayName = "|c00FF00Trinity|r",
            author = "Cline",
            version = Trinity.version,
            registerForRefresh = true,
            registerForDefaults = true,
        }
        local optionsData = {
            {
                type = "description",
                text = "Addon pour afficher les ressources, optimiser le farm, le leveling et proposer le stuff meta.",
            },
            {
                type = "checkbox",
                name = "Afficher les ressources sur la carte",
                getFunc = function() return Trinity.savedVars.showResources or false end,
                setFunc = function(value) Trinity.savedVars.showResources = value end,
                default = true,
            },
        }
        LibAddonMenu2:RegisterAddonPanel("TrinityPanel", panelData)
        LibAddonMenu2:RegisterOptionControls("TrinityPanel", optionsData)
    end

    Trinity.savedVars = ZO_SavedVars:NewAccountWide("TrinitySavedVars", 1, nil, { showResources = true })
    CreateSettingsPanel()

    d("|c00FF00[Trinity]|r Addon chargé.")
end

EVENT_MANAGER:RegisterForEvent(Trinity.name, EVENT_ADD_ON_LOADED, Trinity.OnAddOnLoaded)
